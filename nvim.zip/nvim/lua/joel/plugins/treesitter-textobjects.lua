-- File : treesitter-textobjects.lua
-- Description : Provides better selection shortcuts for things such as functions

return {
  "nvim-treesitter/nvim-treesitter-textobjects",
}
