-- File : init.lua
-- Description : Initial plugins

return {
  "nvim-lua/plenary.nvim", -- useful lua functions that many plugins will use
  "christoomey/vim-tmux-navigator", -- tmux & split window navigation
}
